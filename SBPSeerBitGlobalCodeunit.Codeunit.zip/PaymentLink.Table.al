

/// <summary>
/// Table Required Fields (ID 50105).
/// </summary>

table 71855618
 "SBPPayment Link"
{
    DataClassification = CustomerContent;
    DataCaptionFields = RecId, Customername, PaymentLinkName;
    DrillDownPageId = SBPPaymentLinkSetupList;
    LookupPageId = "SBP PG Payment Link";
    Caption = 'Payment Link Table';


    fields
    {

        field(1; RecId; Integer)
        {
            DataClassification = CustomerContent;
            AutoIncrement = true;

        }
        field(2; Status; Text[20])
        {
            DataClassification = CustomerContent;
            NotBlank = true;
            InitValue = ACTIVE;
        }
        field(20; Amount; Decimal)
        {
            DataClassification = CustomerContent;
            NotBlank = true;
            DecimalPlaces = 2;
            trigger OnValidate()
            begin
                rec.Amount := rec.Amount;
            end;

        }
        field(3; PaymentLinkName; Text[100])
        {
            DataClassification = CustomerContent;
            Editable = true;
            NotBlank = true;

        }
        field(4; Description; Text[250])
        {
            DataClassification = CustomerContent;
        }
        field(5; Currency; Code[10])
        {
            DataClassification = CustomerContent;
        }
        field(6; SuccessMessage; Text[250])
        {
            DataClassification = CustomerContent;
            NotBlank = true;
        }
        field(7; PublicKey; Text[100])
        {
            DataClassification = CustomerContent;
        }
        field(8; CustomizationName; Text[100])
        {
            DataClassification = CustomerContent;


        }
        field(9; PaymentFrequency; Enum "SBP Payment Frequency")
        {
            DataClassification = CustomerContent;


        }
        field(10; PaymentReference; Text[100])
        {
            DataClassification = CustomerContent;
            Caption = 'Account No.';
            TableRelation =
                if ("Account Type" = const("G/L Account")) "G/L Account" where("Account Type" = const(Posting))
            else if ("Account Type" = const(Customer)) Customer
            else if ("Account Type" = const(Vendor)) Vendor
            else if ("Account Type" = const("Bank Account")) "Bank Account"
            else if ("Account Type" = const("Fixed Asset")) "Fixed Asset"
            else if ("Account Type" = const("IC Partner")) "IC Partner"
            else if ("Account Type" = const(Employee)) Employee;
            NotBlank = true;
        }
        field(101; "GL Account Name"; Text[120])
        {
            DataClassification = CustomerContent;
            NotBlank = true;
        }
        field(11; Email; Text[100])
        {
            DataClassification = CustomerContent;
            NotBlank = true;
        }
        field(22; CustomerName; Text[200])
        {
            DataClassification = CustomerContent;
        }
        field(12; address; Boolean)
        {
            DataClassification = CustomerContent;
        }
        field(24; ReqcustomerName; Boolean)
        {
            DataClassification = CustomerContent;
        }
        field(27; ReqAddress; Boolean)
        {
            DataClassification = CustomerContent;
            NotBlank = true;
        }
        field(26; ReqAmount; Boolean)
        {
            DataClassification = CustomerContent;
            NotBlank = true;
        }

        field(25; MobileNumber; Boolean)
        {
            DataClassification = CustomerContent;
        }
        field(28; InvoiceNumber; Boolean)
        {
            DataClassification = CustomerContent;
        }
        field(13; AdditionalData; Text[250])
        {
            DataClassification = CustomerContent;
        }
        field(14; LinkExpirable; Boolean)
        {
            DataClassification = CustomerContent;
        }
        field(15; ExpiryDate; Date)
        {
            DataClassification = CustomerContent;

        }
        field(16; OneTime; Boolean)
        {
            DataClassification = CustomerContent;
        }
        field(21; Reference; Code[20])
        {
            DataClassification = CustomerContent;
        }
        field(30; PaymentLink; Text[250])
        {
            DataClassification = CustomerContent;
        }
        field(33; "General Journal"; Text[250])
        {
            DataClassification = CustomerContent;
            InitValue = 'SEERBIT';
            ObsoleteState = Pending;
            ObsoleteReason = 'This field is no longer used and will be removed in a future version.';
        }
        field(34; "Total Payments"; Integer)
        {
            DataClassification = CustomerContent;
        }
        field(36; "Bal. Account No."; Code[20])
        {
            DataClassification = CustomerContent;
            Caption = 'Bal. Account No.';
            TableRelation =
                if ("Bal. Account Type" = const("G/L Account")) "G/L Account" where("Account Type" = const(Posting))
            else if ("Bal. Account Type" = const(Customer)) Customer
            else if ("Bal. Account Type" = const(Vendor)) Vendor
            else if ("Bal. Account Type" = const("Bank Account")) "Bank Account"
            else if ("Bal. Account Type" = const("Fixed Asset")) "Fixed Asset"
            else if ("Bal. Account Type" = const("IC Partner")) "IC Partner"
            else if ("Bal. Account Type" = const(Employee)) Employee;
        }
        field(37; "Account Type"; Enum "Gen. Journal Account Type")
        {
            DataClassification = CustomerContent;
            InitValue = "Bank Account";
        }
        field(38; "Bal. Account Type"; Enum "Gen. Journal Account Type")
        {
            DataClassification = CustomerContent;
            InitValue = Customer;
        }

    }

    keys
    {
        key(Key1; RecId)
        {
            Clustered = true;

        }

    }





    trigger OnInsert()
    begin


    end;


    trigger OnModify()
    begin

    end;

    trigger OnDelete()
    begin

    end;

    trigger OnRename()
    begin

    end;

}
